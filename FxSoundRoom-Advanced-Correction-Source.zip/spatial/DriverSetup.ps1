$ErrorActionPreference = 'Stop'
$driver = Join-Path $PSScriptRoot 'driver'
$helper = Join-Path $driver 'DfxSetupDrv.exe'
function Get-FxDevice {
    Get-PnpDevice -PresentOnly -Class MEDIA -ErrorAction SilentlyContinue | Where-Object {
        ($_.FriendlyName -eq 'FxSound Audio Enhancer') -or
        ((Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_HardwareIds' -ErrorAction SilentlyContinue).Data -contains 'Root\FXVAD')
    } | Select-Object -First 1
}
try {
    $device = Get-FxDevice
    if (!$device) {
        & (Join-Path $driver 'fxdevcon64.exe') install (Join-Path $driver 'fxvad.inf')
        if ($LASTEXITCODE -ne 0) { throw 'Windows refused the FxSound audio driver.' }
    } elseif ($device.Status -ne 'OK') {
        Enable-PnpDevice -InstanceId $device.InstanceId -Confirm:$false
    }
    $guid = ''
    for ($i=0; $i -lt 15; $i++) {
        $guid = ((& $helper getguid) -join '').Trim()
        if ($guid -match '^(?:\{[0-9.]+\}\.)?\{[a-fA-F0-9-]{36}\}$') { break }
        Start-Sleep -Seconds 1
    }
    if ($guid -notmatch '^(?:\{[0-9.]+\}\.)?\{[a-fA-F0-9-]{36}\}$') { throw 'The virtual playback device is unavailable. Enable FxSound Audio Enhancer in Windows Sound and run setup again.' }
    $key = 'HKLM:\SOFTWARE\DFX\23\devices'
    if (!(Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    New-ItemProperty -Path $key -Name dfx_guid -Value $guid -PropertyType String -Force | Out-Null
    & $helper setname | Out-Null
    $size = ((& $helper defaultbuffersize) -join '').Trim()
    if ($size -match '^\d+$') {
        New-ItemProperty -Path $key -Name default_buffer_size -Value $size -PropertyType String -Force | Out-Null
    }
    exit 0
} catch {
    Write-Output $_.Exception.Message
    exit 1
}
