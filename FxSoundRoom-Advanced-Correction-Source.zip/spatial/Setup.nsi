Unicode true
!include "x64.nsh"
!include "LogicLib.nsh"
Name "FxSound Room Studio"
OutFile "FxSoundRoom-Studio-Manual-Setup.exe"
InstallDir "$PROGRAMFILES64\FxSound Room"
RequestExecutionLevel admin
ShowInstDetails show
Page instfiles
UninstPage uninstConfirm
UninstPage instfiles
Function .onInit
 ${IfNot} ${RunningX64}
  MessageBox MB_OK "This build requires 64-bit Windows."
  Abort
 ${EndIf}
FunctionEnd
Section
 SetShellVarContext all
 SetRegView 64
 SetOutPath "$INSTDIR"
 ClearErrors
 File "FxSoundRoom.exe"
 File "Source.zip"
 File "LICENSE.txt"
 File "DriverSetup.ps1"
 SetOutPath "$INSTDIR\Factsoft"
 File "Factsoft\*.fac"
 SetOutPath "$INSTDIR\driver"
 File "driver\*.*"
 SetOutPath "$INSTDIR"
 ${DisableX64FSRedirection}
 nsExec::ExecToLog '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\DriverSetup.ps1"'
 Pop $0
 ${EnableX64FSRedirection}
 WriteUninstaller "$INSTDIR\Uninstall.exe"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\FxSoundRoom" "DisplayName" "FxSound Room"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\FxSoundRoom" "UninstallString" '"$INSTDIR\Uninstall.exe"'
 CreateShortcut "$SMPROGRAMS\FxSound Room.lnk" "$INSTDIR\FxSoundRoom.exe"
 ${If} $0 != 0
  MessageBox MB_OK "Audio driver setup was incomplete. See Details for the error, then run setup again."
  SetErrorLevel 1
  SetAutoClose false
 ${EndIf}
SectionEnd
Section "Uninstall"
 SetShellVarContext all
 SetRegView 64
 ClearErrors
 Delete "$INSTDIR\FxSoundRoom.exe"
 IfErrors 0 +3
 MessageBox MB_OK "Quit FxSound Room from its tray icon and run Uninstall again."
 Abort
 Delete "$SMPROGRAMS\FxSound Room.lnk"
 DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\FxSoundRoom"
 DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "FxSound Room"
 Delete "$INSTDIR\Source.zip"
 Delete "$INSTDIR\LICENSE.txt"
 Delete "$INSTDIR\DriverSetup.ps1"
 Delete "$INSTDIR\Factsoft\*.fac"
 RMDir "$INSTDIR\Factsoft"
 Delete "$INSTDIR\driver\fxvad.inf"
 Delete "$INSTDIR\driver\fxvad.sys"
 Delete "$INSTDIR\driver\fxvadntamd64.cat"
 Delete "$INSTDIR\driver\fxdevcon64.exe"
 Delete "$INSTDIR\driver\DfxSetupDrv.exe"
 Delete "$INSTDIR\driver\vcruntime140.dll"
 RMDir "$INSTDIR\driver"
 Delete "$INSTDIR\Uninstall.exe"
 RMDir "$INSTDIR"
SectionEnd
