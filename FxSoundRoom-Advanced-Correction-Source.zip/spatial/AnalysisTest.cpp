#include "Analysis.h"
#include <cassert>
#include <cstdio>
int main(){
 using namespace studio;
 for(int sr:{44100,48000,96000})for(bool sub:{false,true}){
  auto p=sweep(sr,sub);int lead=int(sr*.18),lag=int(sr*.0173);std::vector<float> captured(int(sr*1.12));
  for(int i=0;i<(int)p.size();i++)captured[lead+lag+i]=p[i]*.4f;
  auto a=assess(captured,p,sr,lead);assert(a.ok);assert(std::abs(a.latency-1000.*lag/sr)<.2);assert(std::abs(a.level-20*std::log10(.4))<.2);
  captured[500]=1;assert(!assess(captured,p,sr,lead).ok);
  std::fill(captured.begin(),captured.end(),0);assert(!assess(captured,p,sr,lead).ok);}
 puts("PASS: sweep timing, levels and weak/clipped rejection");}
