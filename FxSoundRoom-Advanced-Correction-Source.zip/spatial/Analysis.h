// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <array>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <complex>
#include <vector>
namespace studio {
constexpr double pi=3.14159265358979323846;
template<class T>T limit(T x,T lo,T hi){return (std::max)(lo,(std::min)(hi,x));}
template<class Data> void fft(Data& buf,bool inverse=false){
 const int n=int(buf.size());
 for(int i=1,j=0;i<n;++i){int k=n>>1;while(j&k){j^=k;k>>=1;} j^=k;if(i<j)std::swap(buf[i],buf[j]);}
 for(int len=2;len<=n;len*=2){
  std::complex<double> step=std::polar(1.,(inverse?2:-2)*pi/len);
  for(int s=0;s<n;s+=len){std::complex<double> w(1,0);
   for(int j=0;j<len/2;++j){auto u=buf[s+j],v=w*buf[s+j+len/2];buf[s+j]=u+v;buf[s+j+len/2]=u-v;w*=step;}}
 }
 if(inverse)for(auto& v:buf)v/=n;
}
inline std::vector<float> sweep(int rate,bool sub){
 int len=int(rate*.32);std::vector<float> p(len);
 double low=sub?32.:90., ran=std::log((sub?120.:9000.)/low);
 for(int i=0;i<len;++i){double u=double(i)/len,env=limit((std::min)(u,1-u)*25.,0.,1.);
  p[i]=float(.065*env*std::sin(2*pi*low*.32/ran*std::expm1(ran*u)));}
 return p;
}
struct Reading {bool ok=false;double latency=0,level=0;};
inline Reading assess(const std::vector<float>& mic,const std::vector<float>& ref,int rate,int start){
 Reading a;int n=1;while(n<int(mic.size()+ref.size()))n*=2;
 std::vector<std::complex<double>> x(n),y(n);
 double peak=0;for(size_t i=0;i<mic.size();i++){x[i]=mic[i];peak=(std::max)(peak,std::abs(double(mic[i])));}
 if(peak>.985 || peak<.0002)return a;
 for(size_t i=0;i<ref.size();++i)y[i]=ref[i];fft(x);fft(y);
 auto cross=x;for(int i=0;i<n;++i)cross[i]=x[i]*std::conj(y[i]);fft(cross,true);
 int pos=start;double best=0;for(int i=start;i<(std::min)(int(mic.size()-ref.size()),start+rate/2);++i)
 if(std::abs(cross[i].real())>best){best=std::abs(cross[i].real());pos=i;}
 double e=0,r=0;for(size_t i=0;i<ref.size();++i){e+=double(mic[pos+i])*mic[pos+i];r+=double(ref[i])*ref[i];}
 double noise=0;for(int i=0;i<start/2;i++)noise+=double(mic[i])*mic[i];
 if(best/std::sqrt(e*r+1e-20)<.13 || e/ref.size()<4.*noise/(start/2)+1e-10)return a;
 a.ok=true;a.latency=(pos-start)*1000./rate;a.level=10*std::log10(e/r);
 return a;
}
}
