#include "OutputLimiter.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>
int main(){
 studio::OutputLimiter limiter;
 for(int rate:{44100,48000,96000,192000})for(int channels:{2,8}){
  limiter.stop();
  int length=rate/2;
  std::vector<float> mix(channels*length),original(length);
  for(int f=0;f<length;f++){
   float x=float((f<length/3?.1:1.8)*std::sin(6.283185307*700*f/rate));original[f]=x;
   for(int ch=0;ch<channels;ch++)mix[f*channels+ch]=x/(ch+1);
  }
  for(int f=0;f<length;f+=193)limiter.process(mix.data()+f*channels,std::min(193,length-f),channels,rate);
  float peak=0;int latency=static_cast<int>(std::ceil(.004*rate));
  for(int f=0;f<length;f++){
   float loud=mix[f*channels];peak=std::max(peak,std::abs(loud));
   for(int ch=1;ch<channels;ch++)assert(std::abs(loud-(ch+1)*mix[f*channels+ch])<.0002f);
   if(f>2*latency&&f<length/4)assert(std::abs(loud-original[f-latency])<.0001f);
  }
  assert(peak>.88f&&peak<=.8914f);
 }
 puts("PASS: stereo and 7.1 ceiling, 4 ms latency, linked balance, low-level transparency and rate changes");
}
