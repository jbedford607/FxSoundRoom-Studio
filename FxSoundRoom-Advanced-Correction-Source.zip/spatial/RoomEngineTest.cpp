#include "RoomEngine.h"
#include <cassert>
#include <cstdio>
#include <vector>
using namespace room;
int main(){
 static Engine e; auto& c=controls();constexpr int n=48000;
 std::vector<float> v(n*8);
 auto zero=[&]{for(int i=0;i<count;i++)c.value[i]=spec[i].initial;
 for(int i:{center,sub,sides,roomMix,noteGain,bandGain})c.value[i]=0;
 c.value[enabled]=1;c.value[output]=100;std::fill(v.begin(),v.end(),0);e.reset();};
 auto process=[&]{for(int f=0;f<n;f+=100)e.process(&v[8*f],100,8,48000,0x63f);};
 auto energy=[&](int dest){double s=0;for(int f=0;f<n;f++)s+=v[f*8+dest]*v[f*8+dest];return s;};
 zero();c.value[roomMix]=100;v[0]=v[1]=.4;process();for(int i:{4,5,6,7})assert(energy(i)>0);
 auto tone=[&](int hz){for(int f=0;f<n;++f)v[f*8]=v[f*8+1]=.3*std::sin(6.2831853*hz*f/n);};
 auto tuned=[&](int hz){zero();c.value[noteGain]=100;c.value[noteDest]=4;tone(hz);process();assert(energy(4)==0);return energy(5);};
 assert(tuned(440)>50*tuned(493));
 auto subenergy=[&](int hz){zero();c.value[sub]=100;tone(hz);process();return energy(3);};assert(subenergy(50)>100*subenergy(1200));
 auto high=[&](int hz){zero();c.value[bandGain]=100;tone(hz);process();return energy(6);};assert(high(6000)>20*high(200));
 zero();v[0]=.3;v[1]=-.3;c.value[sides]=100;process();assert(v[6]>.29&&v[7]<-.29&&v[2]==0);
 zero();tone(440);c.value[enabled]=0;auto dry=v;process();assert(v==dry);
 c.value[enabled]=1;e.process(v.data(),n,8,48000,0xff);assert(v==dry);
 c.power=false;process();assert(v==dry);c.power=true;
 puts("PASS: reverb lanes, note tuning + destination, bass and treble selectivity, side extraction, bypass and layout protection");
}
