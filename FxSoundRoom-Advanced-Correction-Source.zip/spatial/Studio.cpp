// SPDX-License-Identifier: AGPL-3.0-or-later
#include <JuceHeader.h>
#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_dsp/juce_dsp.h>
#include "API.h"
#include "RoomPanel.h"
#include "RoomStudioPanel.h"
#include "Analysis.h"
#include "OutputLimiter.h"
#include "AdvancedCorrection.h"
#include "../fxsound/Source/GUI/FxController.h"
#include "../fxsound/Source/GUI/FxMainWindow.h"
#include <numeric>
namespace studio {
using namespace juce;
struct Config{
 std::atomic<int> protect{0},bloom{0},cross{0},reverseSub{0},ir{0},attackSpread{0};
 std::atomic<int> send[8];
 std::atomic<int> secondNote{76},secondDest{4},secondLevel{0};std::atomic<uint32_t> mapping{0x76543210u};
 std::atomic<bool> compare{false},measuring{false};
 String irPath;
 Config(){for(auto& s:send)s=100;}
} cfg;
static OutputLimiter outputLimiter;static float dryEnergy=0,matchGain=1;
static room::Engine spatial;static roomstudio::Engine speakers;static correction::Engine corrections;
struct Filter {double x1=0,x2=0,y1=0,y2=0;float run(float x,const FeqBiquadCoefficients& c){
 const double y=c.b0*x+c.b1*x1+c.b2*x2-c.a1*y1-c.a2*y2;x2=x1;x1=x;y2=y1;y1=std::abs(y)<1.e-22?0:y;return float(y);}};
static Filter bassLow[8][2],bassHigh[8][2];
static Filter extraNote;
bool input(float* p,int frames,int n,int sr){
 if(!p||!frames||n<1||n>8||sr<8000)return false;
 double sum=0;for(int i=0;i<n*frames;i++)sum+=double(p[i])*p[i];
 dryEnergy=float(sum/frames);
 return cfg.compare.load();
}
struct Impulse { dsp::Convolution conv; int rate;
 Impulse(AudioBuffer<float>&& buf,double sr,int outputRate):rate(outputRate){
  conv.loadImpulseResponse(std::move(buf),sr,dsp::Convolution::Stereo::yes,dsp::Convolution::Trim::no,dsp::Convolution::Normalise::yes);
  conv.prepare({double(outputRate),256,2});
 }};
static SpinLock irLock;static std::unique_ptr<Impulse> response;
static String loadIR(File f,int rate){
 WavAudioFormat wav;auto stream=f.createInputStream();if(!stream)return "Cannot open the WAV file.";
 std::unique_ptr<AudioFormatReader> rd(wav.createReaderFor(stream.release(),true));
 if(!rd||rd->lengthInSamples<=0||rd->sampleRate<8000||rd->sampleRate>192000||rd->lengthInSamples>rd->sampleRate*8)return "Choose a WAV impulse response up to 8 seconds long.";
 AudioBuffer<float> audio(jmin(2,(int)rd->numChannels),int(rd->lengthInSamples));
 if(!rd->read(audio.getArrayOfWritePointers(),audio.getNumChannels(),0,audio.getNumSamples()))return "WAV decoding failed.";
 auto next=std::make_unique<Impulse>(std::move(audio),rd->sampleRate,rate);
 {SpinLock::ScopedLockType lock(irLock);response.swap(next);}
 cfg.irPath=f.getFullPathName();return {};
}
// Eight-channel FIR room correction: four separate stereo convolution processors.
// This is not the ambience/reverb impulse processor above. It replaces every
// logical speaker channel with its own calibrated convolution output.
struct CorrectionImpulse {
 std::array<std::unique_ptr<dsp::Convolution>,4> processor;
 int rate=48000;
 CorrectionImpulse(const AudioBuffer<float>& original,double inputRate,int outputRate):rate(outputRate){
  for(int pair=0;pair<4;++pair){
   AudioBuffer<float> ir(2,original.getNumSamples());
   for(int j=0;j<2;++j)ir.copyFrom(j,0,original,2*pair+j,0,original.getNumSamples());
   processor[pair]=std::make_unique<dsp::Convolution>();
   processor[pair]->loadImpulseResponse(std::move(ir),inputRate,dsp::Convolution::Stereo::yes,
      dsp::Convolution::Trim::no,dsp::Convolution::Normalise::no);
   processor[pair]->prepare({double(outputRate),256,2});
  }
 }
 void process(float* p,int samples){
  float channel[8][256];
  for(int i=0;i<samples;++i)for(int ch=0;ch<8;++ch)channel[ch][i]=p[i*8+ch];
  for(int pair=0;pair<4;++pair){
   float* ptr[]={channel[2*pair],channel[2*pair+1]};
   dsp::AudioBlock<float> block(ptr,2,size_t(samples));
   dsp::ProcessContextReplacing<float> context(block);
   processor[pair]->process(context);
  }
  for(int i=0;i<samples;++i)for(int ch=0;ch<8;++ch)p[i*8+ch]=channel[ch][i];
 }
};
static SpinLock correctionIRLock;
static std::unique_ptr<CorrectionImpulse> correctionIR;
static std::atomic<int> useCorrectionIR{0};
static String correctionIRPath;
static File correctionStateFile(){return roomstudio::stateFile().getSiblingFile("advanced-correction.xml");}
static String loadCorrectionIR(const File& wav,int rate){
 if(!wav.existsAsFile())return "Impulse WAV does not exist.";
 WavAudioFormat format;auto stream=wav.createInputStream();if(!stream)return "Cannot open correction WAV.";
 std::unique_ptr<AudioFormatReader> reader(format.createReaderFor(stream.release(),true));
 if(!reader||reader->numChannels!=8||reader->lengthInSamples<=0||reader->lengthInSamples>reader->sampleRate*4||reader->sampleRate<22050||reader->sampleRate>192000)
  return "Select an eight-channel correction WAV, maximum four seconds.";
 AudioBuffer<float> audio(8,int(reader->lengthInSamples));
 if(!reader->read(audio.getArrayOfWritePointers(),8,0,audio.getNumSamples()))return "Unable to decode correction WAV.";
 auto next=std::make_unique<CorrectionImpulse>(audio,reader->sampleRate,rate);
 {SpinLock::ScopedLockType lock(correctionIRLock);correctionIR.swap(next);}
 correctionIRPath=wav.getFullPathName();return {};
}
static void runCorrectionIR(float* audio,int frames,int sr){
 if(!useCorrectionIR.load())return;
 SpinLock::ScopedTryLockType lock(correctionIRLock);
 if(lock.isLocked()&&correctionIR&&correctionIR->rate==sr)correctionIR->process(audio,frames);
}
static void saveCorrections(){
 XmlElement xml("fxsound-advanced-correction-v1");
 xml.setAttribute("enabled",correction::settings().enabled.load());
 xml.setAttribute("convolution",useCorrectionIR.load());
 xml.setAttribute("wav",correctionIRPath);
 for(const auto& f:correction::settings().snapshot()){
  auto* node=xml.createNewChildElement("filter");
  node->setAttribute("channel",f.ch);node->setAttribute("type",f.type);node->setAttribute("hz",f.hz);
  node->setAttribute("gain10",f.gain10);node->setAttribute("q1000",f.q1000);
 }
 auto path=correctionStateFile();path.getParentDirectory().createDirectory();xml.writeTo(path);
}
static void loadCorrections(){
 if(auto xml=XmlDocument::parse(correctionStateFile())){
  std::vector<correction::Filter> values;
  for(int n=0;n<xml->getNumChildElements();++n){auto* el=xml->getChildElement(n);if(!el->hasTagName("filter"))continue;
   values.push_back({el->getIntAttribute("channel",-1),el->getIntAttribute("type",0),el->getIntAttribute("hz",1000),
     el->getIntAttribute("gain10",0),el->getIntAttribute("q1000",1000)});
  }
  if(correction::settings().assign(values))correction::settings().enabled=xml->getIntAttribute("enabled",0)!=0;
  correctionIRPath=xml->getStringAttribute("wav");
  useCorrectionIR=xml->getIntAttribute("convolution",0)!=0 && correctionIRPath.isNotEmpty();
 }
}
static float envelope=0,transient=0;static int previousRate=0;
void render(float* data,int frames,int n,int sr,unsigned mask){
 if(!data || frames<=0)return;
 bool valid=n==8 && mask==0x63f && sr>=22050 && sr<=192000;
 room::controls().rate=sr;room::controls().channels=n;room::controls().valid=valid;
 roomstudio::controls().supported=valid;roomstudio::controls().detectedRate=sr;roomstudio::controls().detectedChannels=n;
 if(cfg.measuring){outputLimiter.stop();std::fill(data,data+frames*n,0.f);return;}
 if(!room::controls().power){outputLimiter.stop();return;}
 const bool protect=cfg.protect&&n>0&&n<=8&&sr>=8000&&sr<=192000;
 if(!protect)outputLimiter.stop();
 bool compare=cfg.compare.load(); bool up=valid && room::controls().value[room::enabled] && !compare;
 bool cal=valid && roomstudio::controls().enabled;
 if(previousRate!=sr){previousRate=sr;spatial.reset();speakers.reset();corrections.reset();envelope=transient=0;for(auto& c:bassLow)for(auto& s:c)s={};for(auto& c:bassHigh)for(auto& s:c)s={};}
 int hz=cal?cfg.cross.load():0;
 FeqBiquadCoefficients lp{},hp{};if(hz){lp=feq_biquad_coefficients(FEQ_FILTER_LPQ,hz,0,.70710678,sr);hp=feq_biquad_coefficients(FEQ_FILTER_HPQ,hz,0,.70710678,sr);}
 int second=cfg.secondLevel.load(),dest=cfg.secondDest.load();FeqBiquadCoefficients tuned{};
 if(up&&second)tuned=feq_biquad_coefficients(FEQ_FILTER_BP,440.*std::pow(2.,(cfg.secondNote-69)/12.),0,35.,sr);else extraNote={};
 uint32_t mapping=cfg.mapping.load();double wetEnergy=0;
 for(int off=0;off<frames;off+=256){
  int len=jmin(256,frames-off);auto* p=data+off*n;
  float dry[256][8],wl[256]{},wr[256]{};bool useIR=false;
  if(up){
   for(int f=0;f<len;f++){std::copy_n(p+f*8,8,dry[f]);wl[f]=dry[f][0];wr[f]=dry[f][1];}
   if(cfg.ir){SpinLock::ScopedTryLockType lock(irLock);if(lock.isLocked()&&response&&response->rate==sr){
    float* ptr[]={wl,wr};dsp::AudioBlock<float> block(ptr,2,len);dsp::ProcessContextReplacing<float> ctx(block);response->conv.process(ctx);useIR=true;}}
   spatial.process(p,len,n,sr,mask,useIR,hz>0,float(cfg.bloom)*.2f,protect);
   const float gain=room::controls().value[room::output]*.01f, mix=room::controls().value[room::roomMix]*.01f;
   const float attackStep=1.f-std::exp(-75.f/sr),release=float(std::exp(-4./sr));
   float amounts[8];for(int k=0;k<8;k++)amounts[k]=cfg.send[k]*.01f;
   for(int f=0;f<len;f++){float* out=p+f*8;float mid=.5f*(dry[f][0]+dry[f][1]);
    envelope=jmax(std::abs(mid),envelope*release);
    if(useIR){float wet=gain*mix/(1+cfg.bloom*.2f*envelope);out[4]+=wl[f]*wet;out[5]+=wr[f]*wet;out[6]+=wl[f]*wet*.5f;out[7]+=wr[f]*wet*.5f;}
    if(second)out[dest]+=extraNote.run(mid,tuned)*second*.01f*gain;
    transient+=(std::abs(mid)-transient)*attackStep;
    if(cfg.attackSpread){float tail=mid*limit(1.f-(std::abs(mid)-transient)*12,0.f,1.f)*cfg.attackSpread*.004f*gain;out[4]+=tail;out[5]+=tail;}
    for(int k=0;k<8;k++)out[k]=dry[f][k]*gain+(out[k]-dry[f][k]*gain)*amounts[k];
   }
  }else spatial.reset();
  for(int f=0;f<len;f++)for(int c=0;c<n;c++){auto& x=p[f*n+c];wetEnergy+=double(x)*x;if(compare)x*=matchGain;}
  if(hz)for(int f=0;f<len;f++){float* x=p+8*f;float lows=0;for(int ch=0;ch<8;ch++)if(ch!=3){
    lows+=bassLow[ch][1].run(bassLow[ch][0].run(x[ch],lp),lp);
    x[ch]=bassHigh[ch][1].run(bassHigh[ch][0].run(x[ch],hp),hp);}
    x[3]+=lows*.5f;}
  if(cal && cfg.reverseSub)for(int f=0;f<len;f++)p[f*8+3]*=-1;
  speakers.process(p,len,n,sr,mask,compare,protect);
  corrections.process(p,len,n,sr,mask,compare||!room::controls().power.load());
  if(valid && !compare && room::controls().power.load())runCorrectionIR(p,len,sr);
  if(valid && mapping!=0x76543210u)for(int f=0;f<len;f++){float reordered[8]{};for(int ch=0;ch<8;ch++)reordered[(mapping>>(ch*4))&7]=p[f*8+ch];std::copy_n(reordered,8,p+f*8);}
 }
 if(protect)outputLimiter.process(data,frames,n,sr);
 if(!compare && dryEnergy>1e-7 && wetEnergy/frames>1e-7){
  float ratio=float(std::sqrt(wetEnergy/frames/dryEnergy));matchGain+=(limit(ratio,.4f,2.5f)-matchGain)*(1.f-std::exp(-float(frames)/sr));}
}

static File settings(){return room::stateFile().getSiblingFile("studio-effects.xml");}
static void saveSettings(){
 XmlElement x("studio2");
 auto put=[&](const char* key,std::atomic<int>& v){x.setAttribute(key,v.load());};
 put("note2",cfg.secondNote);put("note2dest",cfg.secondDest);put("note2mix",cfg.secondLevel);put("protect",cfg.protect);put("bloom",cfg.bloom);put("cross",cfg.cross);put("polarity",cfg.reverseSub);put("useIR",cfg.ir);put("attacks",cfg.attackSpread);
 x.setAttribute("mapping",String::toHexString((int64)cfg.mapping.load()));
 x.setAttribute("impulse",cfg.irPath);
 for(int k=0;k<8;k++){x.setAttribute("send"+String(k),cfg.send[k].load());x.setAttribute("offset"+String(k),roomstudio::controls().channel[k].offsetUs.load());}
 settings().getParentDirectory().createDirectory();x.writeTo(settings());
}
static void loadSettings(){
 roomstudio::restore();
 if(auto x=XmlDocument::parse(settings())){
  auto get=[&](const char* key,std::atomic<int>& v,int hi){v=jlimit(0,hi,x->getIntAttribute(key,v));};
  get("note2",cfg.secondNote,95);get("note2dest",cfg.secondDest,7);get("note2mix",cfg.secondLevel,100);get("protect",cfg.protect,1);get("bloom",cfg.bloom,100);get("cross",cfg.cross,200);get("polarity",cfg.reverseSub,1);get("useIR",cfg.ir,1);get("attacks",cfg.attackSpread,100);
  auto m=uint32_t(x->getStringAttribute("mapping","76543210").getHexValue64());int seen=0;for(int k=0;k<8;k++){auto a=(m>>(k*4))&15;if(a<8)seen|=1<<a;}if(seen==255)cfg.mapping=m;
  cfg.irPath=x->getStringAttribute("impulse");for(int k=0;k<8;k++){
   cfg.send[k]=jlimit(0,150,x->getIntAttribute("send"+String(k),100));
   roomstudio::controls().channel[k].offsetUs=jlimit(-80000,80000,x->getIntAttribute("offset"+String(k),0));
   }
 }
}
class IRRefresh final:public Timer{
 int lastRate=0;
 void timerCallback()override{
  int rate=room::controls().rate;if(rate<22050||rate==lastRate)return;
  lastRate=rate;
  if(cfg.ir&&cfg.irPath.isNotEmpty()&&loadIR(File(cfg.irPath),rate).isNotEmpty())cfg.ir=0;
  if(useCorrectionIR&&correctionIRPath.isNotEmpty()&&loadCorrectionIR(File(correctionIRPath),rate).isNotEmpty())useCorrectionIR=0;
 }
public:IRRefresh(){startTimer(800);}
};
static std::unique_ptr<IRRefresh> refresh;
void load(){loadSettings();loadCorrections();refresh=std::make_unique<IRRefresh>();}
struct Session:AudioIODeviceCallback{
 enum Mode{idle,calibrate,test};Mode mode=idle;
 std::unique_ptr<AudioIODeviceType> type{AudioIODeviceType::createAudioIODeviceType_WASAPI(WASAPIDeviceMode::shared)};
 std::unique_ptr<AudioIODevice> device;
 std::vector<float> recording,normal,bass;
 std::atomic<int> position{0};std::atomic<bool> done{false};
 int rate=48000,span=0,lead=0,selected=0;uint32_t map=0;
 void stop(){if(device){device->stop();device->close();device.reset();}mode=idle;cfg.measuring=false;}
 ~Session()override{stop();}
 String start(Mode next,String out,String in,int ch=0){
  stop();if(!type)return "WASAPI is unavailable.";
  if((out.isEmpty()||out.containsIgnoreCase("FxSound")))return "Choose your physical 7.1 output.";
  if(next!=test && in.isEmpty())return "Choose a Windows recording device.";
  device.reset(type->createDevice(out,next==test?String():in));
  if(!device)return "Windows could not open that input/output pair.";
  BigInteger outputs,inputs;{if(device->getOutputChannelNames().size()<8){stop();return "Set the physical USB endpoint to 7.1 in Windows."; }outputs.setRange(0,8,true);}
  if(next!=test)inputs.setBit(0);
  auto rates=device->getAvailableSampleRates();String error="No shared sample rate between these devices.";
  for(double sr:{48000.,44100.,96000.,88200.,192000.})if(rates.contains(sr)){error=device->open(inputs,outputs,sr,device->getDefaultBufferSize());if(error.isEmpty())break;}
  if(error.isNotEmpty()){stop();return error;}
  rate=int(device->getCurrentSampleRate());lead=int(rate*.18);span=int(rate*1.12);
  normal=sweep(rate,false);bass=sweep(rate,true);selected=ch;map=cfg.mapping;
  recording.assign(next==calibrate?span*8:0,0.f);position=0;done=false;mode=next;cfg.measuring=true;device->start(this);return {};
 }
 void audioDeviceAboutToStart(AudioIODevice*)override{}
 void audioDeviceStopped()override{done=true;}
 void audioDeviceIOCallback(const float** ins,int ni,float** outs,int no,int frames)override{
  for(int ch=0;ch<no;ch++)if(outs[ch])std::fill_n(outs[ch],frames,0.f);
  int pos=position;
  for(int i=0;i<frames;i++){
   float capture=ni && ins && ins[0]?ins[0][i]:0.f;
   if(mode!=test && mode!=calibrate)break;
   int total=span*(mode==test?1:8);if(pos>=total){done=true;break;}
   int ch=mode==test?selected:pos/span, t=pos%span-lead;
   int dest=(map>>(4*ch))&7;auto& wave=ch==3?bass:normal;
   if(dest<no&&outs[dest]&&t>=0&&t<int(wave.size()))outs[dest][i]=wave[t];
   if(mode==calibrate)recording[pos]=capture;++pos;
  }position=pos;
 }
 std::array<Reading,8> results(){
  std::array<Reading,8> result{};if(position<span*8)return result;
  for(int ch=0;ch<8;ch++){auto start=recording.begin()+ch*span;std::vector<float> segment(start,start+span);
   result[ch]=assess(segment,ch==3?bass:normal,rate,lead);}
  return result;
 }
};
static void label(Label& l,String s){l.setText(s,dontSendNotification);}
static void refreshMainEQ(){if(auto* w=dynamic_cast<FxMainWindow*>(FxController::getInstance().getMainWindow()))w->update();}
class MeasurePage final:public Component,private Timer{
 Session io;ComboBox source,output,channel,physical;TextButton start{"Measure all eight"},stop{"Stop"},apply{"Apply suggestions"},test{"Test selected speaker"},reset{"Clear timing offsets"};
 Label description,status,summary,inLabel,outLabel,channelLabel,physicalLabel;std::array<Reading,8> readings{};bool ready=false;int ticks=0;
 void invalidate(){ready=false;apply.setEnabled(false);label(summary,"");}
 void begin(bool measuring){
  io.stop();invalidate();auto err=io.start(measuring?Session::calibrate:Session::test,output.getText(),source.getText(),channel.getSelectedId()-1);
  label(status,err.isEmpty()?(measuring?"Measuring...":"Playing selected channel..."):err);ticks=0;
 }
 void timerCallback()override{
  if(io.mode==Session::idle)return;
  if(++ticks>200){io.stop();label(status,"Audio device stopped responding. Check the selected endpoints.");return;}
  if(!io.done){if(io.mode==Session::calibrate)label(status,"Measuring "+String(roomstudio::speakerName[jmin(7,io.position.load()/io.span)]));return;}
  auto mode=io.mode;io.stop();
  if(mode==Session::test){label(status,"Speaker test complete.");return;}
  readings=io.results();ready=std::all_of(readings.begin(),readings.end(),[](auto a){return a.ok;});
  String text;
  for(int i=0;i<8;i++){auto& a=readings[i];text+=String(roomstudio::speakerName[i])+"    "+(a.ok?String(a.level,1)+" dB    "+String(a.latency,1)+" ms":"Weak, clipped or unmatched sweep")+"\n";}
  label(summary,text);label(status,ready?"Review levels and arrival times, then apply.":"Check mic level and speaker routing, then measure again.");
  apply.setEnabled(ready);
 }
 void commit(){
  if(!ready)return;
  std::vector<double> levels;double slowest=0;int farthest=0;
  auto& c=roomstudio::controls();
  for(int i=0;i<8;i++){if(i!=3)levels.push_back(readings[i].level);slowest=jmax(slowest,readings[i].latency);farthest=jmax(farthest,c.channel[i].distanceCm.load());}
  std::sort(levels.begin(),levels.end());const double target=levels[2];
  for(int i=0;i<8;i++){auto& ch=c.channel[i];auto& a=readings[i];
   double geo=(farthest-ch.distanceCm.load())/34.3;ch.offsetUs=int(1000*limit(slowest-a.latency-geo,-80.,80.));
   if(i==3)continue;ch.gainTenths=int(std::round(10*limit(target-a.level,-9.,3.)));
   }
  c.enabled=1;roomstudio::save();saveSettings();ready=false;apply.setEnabled(false);
  label(status,"Applied speaker timing and main speaker levels. Sub level stays manual.");}
 void syncMap(){int i=channel.getSelectedId()-1;physical.setSelectedId(1+int((cfg.mapping.load()>>(4*i))&7),dontSendNotification);}
public:
 MeasurePage(){
  for(Component* p:std::initializer_list<Component*>{&source,&output,&channel,&physical,&start,&stop,&apply,&test,&reset,&description,&status,&summary,&inLabel,&outLabel,&channelLabel,&physicalLabel})addAndMakeVisible(p);
  label(description,"Pause music. Place your microphone at your chair. Sweeps play directly on the selected 7.1 output.");
  label(inLabel,"Measurement input");label(outLabel,"Physical output");label(channelLabel,"Logical speaker");label(physicalLabel,"USB output channel");
  summary.setJustificationType(Justification::topLeft);
  if(io.type){io.type->scanForDevices();int id=1;for(auto s:io.type->getDeviceNames(true))source.addItem(s,id++);source.setSelectedId(1);
   auto goal=String(FxModel::getModel().getSelectedOutput().deviceFriendlyName.c_str());id=1;for(auto s:io.type->getDeviceNames(false))if(!s.containsIgnoreCase("FxSound")){output.addItem(s,id);if(goal.equalsIgnoreCase(s))output.setSelectedId(id);++id;}
   if(!output.getSelectedId())output.setSelectedId(1);}
  for(int i=0;i<8;i++){channel.addItem(roomstudio::speakerName[i],i+1);physical.addItem(roomstudio::speakerName[i],i+1);}channel.setSelectedId(1);syncMap();
  channel.onChange=[this]{syncMap();};physical.onChange=[this]{io.stop();invalidate();int i=channel.getSelectedId()-1,d=physical.getSelectedId()-1;auto m=cfg.mapping.load();int old=(m>>(i*4))&7;
   for(int k=0;k<8;k++)if(((m>>(k*4))&7)==d){m=(m&~(15u<<(4*k)))|(uint32_t(old)<<(4*k));break;}
   cfg.mapping=(m&~(15u<<(4*i)))|(uint32_t(d)<<(4*i));saveSettings();};
  output.onChange=source.onChange=[this]{io.stop();invalidate();};
  start.onClick=[this]{begin(true);};test.onClick=[this]{begin(false);};stop.onClick=[this]{io.stop();invalidate();label(status,"Stopped.");};
  apply.onClick=[this]{commit();};reset.onClick=[this]{for(auto& c:roomstudio::controls().channel)c.offsetUs=0;saveSettings();label(status,"Manual map distances now determine all delays.");};
  apply.setEnabled(false);startTimerHz(10);}
 void visibilityChanged()override{if(!isShowing()&&io.mode!=Session::idle)io.stop();}
 void resized()override{auto a=getLocalBounds().reduced(20);description.setBounds(a.removeFromTop(45));auto row=[&](Label& l,ComboBox& b){auto r=a.removeFromTop(36);l.setBounds(r.removeFromLeft(170));b.setBounds(r.removeFromLeft(425).reduced(1,3));};row(inLabel,source);row(outLabel,output);row(channelLabel,channel);row(physicalLabel,physical);
  a.removeFromTop(10);auto buttons=a.removeFromTop(32);for(auto* b:{&test,&start,&stop,&apply,&reset})b->setBounds(buttons.removeFromLeft(b==&stop?62:156).reduced(2,0));status.setBounds(a.removeFromTop(49));summary.setBounds(a);}
};
class SpacePage final:public Component {
 Label descriptions[9],fileInfo;Slider sliders[5];ComboBox noteKey,noteOut,algorithm,outputSpeaker;
 TextButton choose{"Load impulse WAV"};ToggleButton inverted{"Invert sub polarity"};
 int activeSend=0;
 void slider(int i,const char* name,int minValue,int maxValue,std::atomic<int>& setting){
  label(descriptions[i],name);auto& s=sliders[i];s.setRange(minValue,maxValue,1);s.setValue(setting.load(),dontSendNotification);
  s.setTextBoxStyle(Slider::TextBoxRight,false,55,22);s.onValueChange=[&setting,&s]{setting=int(s.getValue());};s.onDragEnd=[]{saveSettings();};
 }
public:
 SpacePage(){
  for(auto& l:descriptions)addAndMakeVisible(l);for(auto& s:sliders)addAndMakeVisible(s);
  for(Component* p:std::initializer_list<Component*>{&algorithm,&choose,&fileInfo,&outputSpeaker,&noteKey,&noteOut,&inverted})addAndMakeVisible(p);
  slider(0,"Reverb ducking / bloom (%)",0,100,cfg.bloom);
  slider(1,"Rear decay spread (%)",0,100,cfg.attackSpread);
  slider(2,"Bass crossover Hz (0 = off)",0,200,cfg.cross);
  sliders[2].onValueChange=[this]{int v=int(sliders[2].getValue());cfg.cross=v<30?0:v;};sliders[2].onDragEnd=[this]{sliders[2].setValue(cfg.cross.load(),dontSendNotification);saveSettings();};
  slider(3,"Selected speaker effect send (%)",0,150,cfg.send[0]);
  sliders[3].onValueChange=[this]{cfg.send[activeSend]=int(sliders[3].getValue());};
  for(int k=0;k<8;k++)outputSpeaker.addItem(roomstudio::speakerName[k],k+1);
  outputSpeaker.setSelectedId(1,dontSendNotification);outputSpeaker.onChange=[this]{activeSend=outputSpeaker.getSelectedId()-1;sliders[3].setValue(cfg.send[activeSend].load(),dontSendNotification);};
  const char* pitches[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
  for(int m=36;m<96;m++)noteKey.addItem(String(pitches[m%12])+String(m/12-1),m+1);
  for(int k=0;k<8;k++)if(k!=3)noteOut.addItem(roomstudio::speakerName[k],k+1);
  noteKey.setSelectedId(cfg.secondNote+1,dontSendNotification);noteOut.setSelectedId(cfg.secondDest+1,dontSendNotification);
  noteKey.onChange=[this]{cfg.secondNote=noteKey.getSelectedId()-1;saveSettings();};noteOut.onChange=[this]{cfg.secondDest=noteOut.getSelectedId()-1;saveSettings();};
  sliders[4].setRange(0,100,1);sliders[4].setValue(cfg.secondLevel.load(),dontSendNotification);sliders[4].setTextBoxStyle(Slider::TextBoxRight,false,50,22);
  sliders[4].onValueChange=[this]{cfg.secondLevel=int(sliders[4].getValue());};sliders[4].onDragEnd=[]{saveSettings();};
  label(descriptions[7],"Second tuned send");label(descriptions[8],"Reverb algorithm");label(descriptions[5],"Effect destination");
  label(descriptions[6],"Reverb and sends use the 7.1 upmix. Bass management uses Speaker Room.");
  label(fileInfo,cfg.irPath.isEmpty()?"No WAV selected":File(cfg.irPath).getFileName());
  algorithm.addItem("Feedback room",1);algorithm.addItem("WAV convolution",2);algorithm.setSelectedId(cfg.ir?2:1,dontSendNotification);
  algorithm.onChange=[this]{if(algorithm.getSelectedId()==2&&cfg.irPath.isEmpty()){algorithm.setSelectedId(1,dontSendNotification);label(fileInfo,"Load a WAV first.");}cfg.ir=algorithm.getSelectedId()==2;saveSettings();};
  choose.onClick=[this]{FileChooser fc("Select a room impulse response",{},"*.wav");if(fc.browseForFileToOpen()){
   int sampleRate=room::controls().rate;String err=loadIR(fc.getResult(),sampleRate>0?sampleRate:48000);if(err.isEmpty()){cfg.ir=1;algorithm.setSelectedId(2,dontSendNotification);label(fileInfo,fc.getResult().getFileName());saveSettings();}else label(fileInfo,err);}};
  inverted.setToggleState(cfg.reverseSub,dontSendNotification);inverted.onClick=[this]{cfg.reverseSub=inverted.getToggleState();saveSettings();};
 }
 void resized()override{auto a=getLocalBounds().reduced(22);descriptions[6].setBounds(a.removeFromTop(33));auto r=a.removeFromTop(35);
  descriptions[8].setBounds(r.removeFromLeft(220));algorithm.setBounds(r.removeFromLeft(185));choose.setBounds(r.removeFromLeft(160));fileInfo.setBounds(r);
  for(int i=0;i<4;++i){if(i==3){r=a.removeFromTop(37);descriptions[5].setBounds(r.removeFromLeft(220));outputSpeaker.setBounds(r.removeFromLeft(230));}
   r=a.removeFromTop(42);descriptions[i].setBounds(r.removeFromLeft(250));sliders[i].setBounds(r.removeFromLeft(360));if(i==2)inverted.setBounds(r);}
  r=a.removeFromTop(32);descriptions[7].setBounds(r.removeFromLeft(150));noteKey.setBounds(r.removeFromLeft(90));noteOut.setBounds(r.removeFromLeft(165));sliders[4].setBounds(r.removeFromLeft(240));}
};
// The correction page controls actual DSP modules rather than placeholder UI.
// REW text import and Equalizer APO export use the complete native 32-band/channel bank.
class CorrectionPage final:public Component {
 ToggleButton enabled{"Enable imported EQ"},fir{"Enable 7.1 correction convolution"};
 ComboBox target;
 TextButton loadEQ{"Import REW / APO .txt"},exportEQ{"Export APO .txt"},exportCamilla{"Export CamillaDSP YAML"},loadWav{"Load 7.1 correction WAV"},clear{"Clear all correction"};
 Label heading,explain,status,irInfo;
 void update(){
  auto filters=correction::settings().snapshot();
  label(status,String(filters.size())+" imported filter assignments across eight channels");
  enabled.setToggleState(correction::settings().enabled.load()!=0,dontSendNotification);
  fir.setToggleState(useCorrectionIR.load()!=0,dontSendNotification);
  label(irInfo,correctionIRPath.isEmpty()?"No correction impulse loaded":File(correctionIRPath).getFileName());
 }
 static const char* shortName(int type){static const char* names[]={"PK","LSC","HSC","LPQ","HPQ","BP"};return names[jlimit(0,5,type)];}
public:
 CorrectionPage(){
  for(Component* p:std::initializer_list<Component*>{&enabled,&fir,&target,&loadEQ,&exportEQ,&exportCamilla,&loadWav,&clear,&heading,&explain,&status,&irInfo})addAndMakeVisible(p);
  label(heading,"Measured speaker correction (up to 32 bands per speaker)");
  label(explain,"Import REW/Equalizer APO parametric filters; use Cavern QuickEQ 8-channel convolution WAV for full FIR correction. GraphicEQ needs APO.");
  target.addItem("Use Channel: routing in the file (or all channels)",1);
  for(int i=0;i<8;i++)target.addItem(roomstudio::speakerName[i],i+2);
  target.setSelectedId(1,dontSendNotification);
  enabled.onClick=[this]{correction::settings().enabled=enabled.getToggleState()?1:0;saveCorrections();};
  fir.onClick=[this]{if(correctionIRPath.isEmpty())fir.setToggleState(false,dontSendNotification);
    useCorrectionIR=fir.getToggleState()?1:0;saveCorrections();};
  loadEQ.onClick=[this]{FileChooser fc("Select REW or Equalizer APO parametric EQ text",{},"*.txt");if(!fc.browseForFileToOpen())return;
   auto file=fc.getResult();if(file.getSize()>1024*1024){label(status,"File exceeds the 1 MB limit.");return;}
   auto r=correction::parse(file.loadFileAsString().toStdString(),target.getSelectedId()==1?-1:target.getSelectedId()-2);
   if(!r.error.empty()){label(status,String(r.error.c_str()));return;}
   if(!correction::settings().assign(r.filters)){label(status,"Invalid or excess filters. Maximum 32 per channel.");return;}
   correction::settings().enabled=1;saveCorrections();update();};
  clear.onClick=[this]{correction::settings().clear();useCorrectionIR=0;correctionIRPath.clear();
   {SpinLock::ScopedLockType lock(correctionIRLock);correctionIR.reset();}saveCorrections();update();};
  loadWav.onClick=[this]{FileChooser fc("Select eight-channel correction impulse WAV",{},"*.wav");if(!fc.browseForFileToOpen())return;
   int sr=room::controls().rate;auto err=loadCorrectionIR(fc.getResult(),sr>=22050?sr:48000);
   if(err.isNotEmpty()){label(status,err);return;}useCorrectionIR=1;saveCorrections();update();};
  exportEQ.onClick=[this]{auto list=correction::settings().snapshot();if(list.empty()){label(status,"Import correction filters first.");return;}
   FileChooser fc("Export Equalizer APO correction",File::getSpecialLocation(File::userDocumentsDirectory).getChildFile("FxSoundRoom-correction.txt"),"*.txt");
   if(!fc.browseForFileToSave(true))return;
   String file="# FxSound Room Studio - multichannel EQ. Use only on your intended Windows 7.1 endpoint.\n";
   const char* channels[]={"L","R","C","LFE","RL","RR","SL","SR"};
   for(int ch=0;ch<8;ch++){file+="Channel: "+String(channels[ch])+"\n";
    for(auto& f:list)if(f.ch==ch){file+="Filter: ON "+String(shortName(f.type))+" Fc "+String(f.hz)+" Hz Gain "+String(f.gain10*.1,1)+" dB Q "+String(f.q1000*.001,3)+"\n";}}
   if(fc.getResult().replaceWithText(file))label(status,"Exported APO filters. Enable through Equalizer APO only on the target endpoint.");
   else label(status,"Could not write the output file.");};
  exportCamilla.onClick=[this]{auto list=correction::settings().snapshot();if(list.empty()){label(status,"Import correction filters first.");return;}
   FileChooser fc("Export CamillaDSP filter/pipeline snippet",File::getSpecialLocation(File::userDocumentsDirectory).getChildFile("FxSoundRoom-CamillaDSP.yml"),"*.yml");
   if(!fc.browseForFileToSave(true))return;
   String yaml="# CamillaDSP filters and pipeline snippet only. Merge into a config with your WASAPI devices.\nfilters:\n";
   for(int ch=0;ch<8;ch++){int num=0;for(auto& f:list)if(f.ch==ch){
     const char* types[]={"Peaking","Lowshelf","Highshelf","Lowpass","Highpass","Bandpass"};
     yaml+="  ch"+String(ch)+"_eq"+String(++num)+":\n    type: Biquad\n    parameters:\n";
     yaml+="      type: "+String(types[jlimit(0,5,f.type)])+"\n      freq: "+String(f.hz)+"\n";
     if(f.type<=correction::highShelf)yaml+="      gain: "+String(f.gain10*.1,1)+"\n";
     yaml+="      q: "+String(f.q1000*.001,3)+"\n";
   }}
   yaml+="pipeline:\n";
   for(int ch=0;ch<8;ch++){int num=0;for(auto& f:list)if(f.ch==ch)++num;
     if(!num)continue;
     yaml+="  - type: Filter\n    channels: ["+String(ch)+"]\n    names:\n";
     for(int i=1;i<=num;++i)yaml+="      - ch"+String(ch)+"_eq"+String(i)+"\n";
   }
   if(fc.getResult().replaceWithText(yaml))label(status,"Exported CamillaDSP filters/pipeline. Select audio devices in CamillaGUI before running.");
   else label(status,"Could not write CamillaDSP YAML.");};
  update();
 }
 void resized()override{
  auto a=getLocalBounds().reduced(25);heading.setBounds(a.removeFromTop(32));explain.setBounds(a.removeFromTop(58));a.removeFromTop(14);
  enabled.setBounds(a.removeFromTop(35));auto r=a.removeFromTop(35);target.setBounds(r.removeFromLeft(415));
  a.removeFromTop(9);r=a.removeFromTop(36);loadEQ.setBounds(r.removeFromLeft(208));r.removeFromLeft(8);exportEQ.setBounds(r.removeFromLeft(208));r.removeFromLeft(8);exportCamilla.setBounds(r.removeFromLeft(208));
  a.removeFromTop(20);fir.setBounds(a.removeFromTop(35));r=a.removeFromTop(36);loadWav.setBounds(r.removeFromLeft(245));r.removeFromLeft(15);irInfo.setBounds(r);
  a.removeFromTop(20);clear.setBounds(a.removeFromTop(35).removeFromLeft(190));status.setBounds(a.removeFromTop(60));
 }
};
class PageView final:public Viewport {
public:explicit PageView(Component* page){setViewedComponent(page,true);setScrollBarsShown(true,true);}
};
class StudioPanel final:public Component,private Timer{
 TabbedComponent tabs{TabbedButtonBar::TabsAtTop};ToggleButton protection{"Limit peaks (-1 dBFS)"},ab{"A/B: original, level matched"};Label status;
 void timerCallback()override{auto& c=room::controls();String s=c.channels.load()?String(c.channels.load())+" channels  /  "+String(c.rate.load())+" Hz":"Play audio to detect the output";
  if(c.channels&& !c.valid)s+="  /  7.1 routing unavailable";if(!c.power)s+="  /  FxSound off";label(status,s);}
public:
 StudioPanel(){for(Component* p:std::initializer_list<Component*>{&tabs,&ab,&protection,&status})addAndMakeVisible(p);
  auto tab=[this](String title,Component* p){tabs.addTab(title,Colour(0xff182c47),p,true);};
  tab("7.1 routing",new PageView(new room::Panel));tab("Spatial FX",new SpacePage);tab("Correction",new PageView(new CorrectionPage));tab("Speaker room",new PageView(new roomstudio::Panel));tab("Mic & mapping",new MeasurePage);
  protection.setToggleState(cfg.protect.load()!=0,dontSendNotification);
  protection.onClick=[this]{cfg.protect=protection.getToggleState();saveSettings();};
  ab.onClick=[this]{cfg.compare=ab.getToggleState();};timerCallback();startTimerHz(3);
  auto screen=Desktop::getInstance().getDisplays().getPrimaryDisplay()->userArea;setSize(jmin(1030,screen.getWidth()-45),jmin(755,screen.getHeight()-70));}
 ~StudioPanel()override{cfg.compare=false;cfg.measuring=false;saveSettings();}
 void resized()override{auto a=getLocalBounds();auto top=a.removeFromTop(36).reduced(9,1);ab.setBounds(top.removeFromRight(252));protection.setBounds(top.removeFromRight(188));status.setBounds(top);tabs.setBounds(a);}
};
void open(){static Component::SafePointer<DialogWindow> win;if(win){win->toFront(true);return;}
 DialogWindow::LaunchOptions o;o.dialogTitle="FxSound Room Studio";o.dialogBackgroundColour=Colour(0xff112238);o.content.setOwned(new StudioPanel);o.useNativeTitleBar=true;o.resizable=true;win=o.launchAsync();}
void shut(){refresh.reset();saveSettings();saveCorrections();}
}
