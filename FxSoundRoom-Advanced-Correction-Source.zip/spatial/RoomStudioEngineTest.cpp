#include "RoomStudioEngine.h"
#include "RoomEngine.h"
#include <cstdio>
#include <cassert>
#include <cmath>
#include <vector>
using namespace roomstudio;
constexpr int sr=48000;
constexpr int frames=48000;
static std::vector<float> buffer(frames*8);
static void silence(){std::fill(buffer.begin(),buffer.end(),0.f);}
static void resetControls(){
 Controls& c=controls();c.enabled=0;c.soloMask=0;c.testSpeaker=-1;
 c.widthPercent=100;c.wrapPercent=0;c.wrapDelayMs=25;
 for(int ch=0;ch<8;++ch){
  c.channel[ch].enabled=1;c.channel[ch].gainTenths=0;c.channel[ch].distanceCm=200;
  for(int b=0;b<3;++b){c.channel[ch].eqTenths[b]=0;c.channel[ch].eqFreq[b]= b==0?125:b==1?1000:6000;c.channel[ch].eqQ100[b]=100;}
 }
}
static double energy(int ch){double total=0;for(int f=0;f<frames;++f){auto v=buffer[f*8+ch];total+=v*v;}return total;}
static void tone(int freq,int ch){for(int f=0;f<frames;++f)buffer[f*8+ch]=float(.22*sin(6.28318530718*freq*f/sr));}
static bool approx(double a,double b,double epsilon=.02){return std::abs(a-b)<epsilon;}
int main(){
 Engine e;resetControls();silence();tone(440,0);
 auto unchanged=buffer;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(buffer==unchanged); // 1. DEFAULT BYPASS guarantees the original signal
 assert(controls().supported==1 && controls().detectedRate==sr);
 resetControls();e.reset();controls().enabled=1;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(buffer==unchanged); // 2. Neutral enabled processing is transparent for mono front signal
 resetControls();e.reset();controls().enabled=1;
 controls().channel[0].enabled=0;e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(0)==0); // 3. real per speaker mute
 resetControls();e.reset();silence();tone(440,0);tone(440,1);
 controls().enabled=1;controls().channel[0].gainTenths=-60;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(0) < energy(1)*.3 && energy(0)>energy(1)*.2); // 4. -6dB channel only
 resetControls();e.reset();silence();tone(440,0);tone(440,1);
 controls().enabled=1;controls().soloMask=2;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(0)==0 && energy(1)>0); // 5. solo mask
 resetControls();e.reset();silence();tone(1000,0);tone(1000,1);
 controls().enabled=1;controls().channel[0].eqTenths[1]=60;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(0)>energy(1)*3.6); // 6. per-speaker EQ boosts tuned freq
 resetControls();e.reset();silence();tone(1000,0);tone(1000,1);
 controls().enabled=1;controls().channel[0].eqTenths[1]=-60;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(0)<energy(1)*.3); // 7. EQ attenuation
 resetControls();e.reset();silence();buffer[0]=1;buffer[1]=1;
 controls().enabled=1;controls().channel[0].distanceCm=100;
 controls().channel[1].distanceCm=200;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(buffer[0]==0 && approx(buffer[1],1));
 assert(buffer[8*50]==0 && buffer[8*100]==0); // 8. timing alignment defers near speaker
 assert(energy(0)>.4); // 9. no energy lost to alignment
 resetControls();e.reset();silence();tone(440,0);tone(440,1);
 controls().enabled=1;controls().widthPercent=0;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(approx(energy(0),energy(1),.001)); // 10. width collapses difference (equal input)
 resetControls();e.reset();silence();tone(440,0);
 controls().enabled=1;controls().wrapPercent=80;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(4)>0&&energy(5)>0&&energy(6)>0&&energy(7)>0); // 11. 4 discrete reflections
 resetControls();e.reset();silence();controls().enabled=1;controls().testSpeaker=3;
 e.process(buffer.data(),frames,8,sr,speakerMask71);
 assert(energy(3)>0 && energy(2)==0 && energy(0)==0); // 12. speaker diagnostic tone
 resetControls();e.reset();silence();tone(440,0);controls().enabled=1;unchanged=buffer;
 e.process(buffer.data(),frames,2,sr,3);
 assert(buffer==unchanged); // 13. no invalid output format modifications
 resetControls();e.reset();silence();tone(440,0);controls().enabled=1;unchanged=buffer;
 room::controls().power=false;e.process(buffer.data(),frames,8,sr,speakerMask71);room::controls().power=true;
 assert(buffer==unchanged); // 14. original FxSound power button also bypasses Studio
 puts("PASS 14 tests: base bypass, unity, speaker mute/gain/solo, 3-band PEQ, delay, width, wrap, 7.1 tone, layout guard");
}
