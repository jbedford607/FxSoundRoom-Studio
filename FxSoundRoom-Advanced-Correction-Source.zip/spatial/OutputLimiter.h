// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <algorithm>
#include "vendor/signalsmith-basics/limiter.h"

namespace studio {
class OutputLimiter {
 signalsmith::basics::LimiterFloat limiter{16};
 int lastRate=0, lastChannels=0;
 bool running=false;
public:
 void stop(){running=false;}
 void process(float* interleaved,int frames,int channels,int sr){
  if(!running || sr!=lastRate || channels!=lastChannels){
   limiter.attackMs=4; limiter.holdMs=2; limiter.releaseMs=80;
   limiter.linkChannels=1; limiter.inputGain=1; limiter.outputLimit=std::pow(10.,-1./20.);
   if(sr!=lastRate||channels!=lastChannels){
    if(!limiter.configure(sr,256,channels)){stop();return;}
    lastRate=sr;lastChannels=channels;
   }
   limiter.reset();running=true;
  }
  float input[8][256],output[8][256];float* src[8],*dst[8];
  for(int ch=0;ch<channels;++ch){src[ch]=input[ch];dst[ch]=output[ch];}
  for(int offset=0;offset<frames;offset+=256){
   int length=std::min(256,frames-offset);
   for(int f=0;f<length;++f)for(int ch=0;ch<channels;++ch)input[ch][f]=interleaved[(offset+f)*channels+ch];
   limiter.process(src,dst,length);
   for(int f=0;f<length;++f)for(int ch=0;ch<channels;++ch)interleaved[(offset+f)*channels+ch]=output[ch][f];
  }
 }
};
}
