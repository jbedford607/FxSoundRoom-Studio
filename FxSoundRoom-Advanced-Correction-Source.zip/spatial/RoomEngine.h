// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

namespace room {
enum Param { enabled, center, sub, sides, roomMix, decay, note,
             noteGain, noteDest, splitHz, bandGain, bandDest, output, count };
struct Spec { const char* label; int lo, hi, initial; };
constexpr Spec spec[count] = {
 {"Enable 7.1 upmix",0,1,0},{"Centre fill",0,100,35},{"Sub below 85 Hz",0,100,30},
 {"Stereo ambience to sides",0,100,45},{"Surround reverb",0,100,24},
 {"Reverb feedback",0,85,52},
 {"Note",36,95,69},{"Tuned note send",0,100,30},{"Note destination",0,6,4},
 {"High-pass cutoff (Hz)",200,10000,2600},{"High-frequency send",0,100,28},
 {"High-frequency destination",0,6,5},{"Output level",10,100,80}
};
struct Controls {
 std::atomic<int> value[count];
 std::atomic<int> channels{0}, valid{0}, rate{0};
 std::atomic<bool> power{true};
 Controls(){for(int i=0;i<count;++i) value[i].store(spec[i].initial);}
};
inline Controls& controls(){static Controls c; return c;}
constexpr int destIndex[7]={0,1,2,4,5,6,7};
class Engine {
 std::array<std::array<float,16384>,4> verb{};
 unsigned pos=0, history=0;
 int previousRate=0;
 bool active=false;
 float envelope=0;
 float bass1=0,bass2=0,highLP=0,z1=0,z2=0;
 static float clip(float x){return (std::max)(-1.f,(std::min)(1.f,x));}
public:
 void reset(){history=0;pos=0;envelope=0;bass1=bass2=highLP=z1=z2=0;active=false;}
 void process(float* samples,int frames,int n,int rate,unsigned speakerMask,bool ir=false,bool bassManaged=false,float bloom=0.f,bool protect=false){
  auto& c=controls();
  bool supported=n==8 && speakerMask==0x63f && rate>=22050 && rate<=192000;
  c.channels.store(n); c.valid.store(supported); c.rate.store(rate);
  if(!supported || !c.value[enabled].load() || !c.power.load()){reset();return;}
  if(!active || previousRate!=rate){reset();active=true;previousRate=rate;}
  int p[count];for(int i=0;i<count;++i)p[i]=c.value[i].load();
  constexpr double pi=3.141592653589793;
  float bassCoeff=1-std::exp(-2*pi*85/rate), highCoeff=1-std::exp(-2*pi*p[splitHz]/rate);
  const double hz=440*std::pow(2.,(p[note]-69)/12.), w=2*pi*hz/rate;
  const float a=std::sin(w)/(2*40.), b=a/(1+a), a1=-2*std::cos(w)/(1+a), a2=(1-a)/(1+a);
  const unsigned delays[]={unsigned(rate*.0297),unsigned(rate*.0371),unsigned(rate*.0411),unsigned(rate*.0437)};
  for(int f=0;f<frames;++f,samples+=n){
   float l=samples[0],r=samples[1], mid=.5f*(l+r),side=.5f*(l-r);
   envelope=(std::max)(std::abs(mid),envelope*(1.f-4.f/rate));
   bass1+=bassCoeff*(mid-bass1);bass2+=bassCoeff*(bass1-bass2);
   highLP+=highCoeff*(mid-highLP);
   float resonant=b*mid+z1; z1=z2-a1*resonant;z2=-b*mid-a2*resonant;
   samples[2]+=mid*p[center]*.01f; if(!bassManaged)samples[3]+=bass2*p[sub]*.01f;
   samples[6]+=side*p[sides]*.01f; samples[7]-=side*p[sides]*.01f;
   samples[destIndex[p[noteDest]]]+=resonant*p[noteGain]*.01f;
   samples[destIndex[p[bandDest]]]+=(mid-highLP)*p[bandGain]*.01f;
   float reflections[4],sum=0;
   for(int i=0;i<4;++i){
    reflections[i]=history>=delays[i]?verb[i][(pos-delays[i])&16383]:0;
    sum+=reflections[i];
   }
   const int route[]={7,5,4,6};
   for(int i=0;i<4;++i){
    if(!ir)samples[route[i]]+=reflections[i]*p[roomMix]*.01f/(1.f+bloom*envelope);
    verb[i][pos&16383]=.3f*(i%2?r:l)+(sum*.5f-reflections[i])*p[decay]*.01f;
   }
   ++pos;if(history<16384)++history;
   for(int i=0;i<n;++i){samples[i]*=p[output]*.01f;if(!protect)samples[i]=clip(samples[i]);}
  }
 }
};
}
