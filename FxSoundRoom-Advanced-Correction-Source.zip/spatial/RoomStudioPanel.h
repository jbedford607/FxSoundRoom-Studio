// FxSound Room Studio GUI add-on; AGPL-3.0-or-later.
// Uses the same JUCE installation as the original FxSound UI.
#pragma once
#include <JuceHeader.h>
#include "RoomStudioEngine.h"
#include "RoomEngine.h"
#include <functional>

namespace roomstudio {
inline juce::File stateFile(){
 return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
    .getChildFile("FxSound Room").getChildFile("studio.xml");
}
inline void restore(){
 if(auto xml=juce::XmlDocument::parse(stateFile())){
  auto& c=controls();
  c.enabled=xml->getIntAttribute("enabled",0)==1;
  c.widthPercent=juce::jlimit(0,200,xml->getIntAttribute("width",100));
  c.wrapPercent=juce::jlimit(0,80,xml->getIntAttribute("wrap",0));
  c.wrapDelayMs=juce::jlimit(5,70,xml->getIntAttribute("wrapMs",25));
  for(int ch=0;ch<speakers;++ch){
   auto* s=xml->getChildByName("speaker"+juce::String(ch));
   if(!s)continue;
   auto& dst=c.channel[ch];
   dst.enabled=juce::jlimit(0,1,s->getIntAttribute("on",1));
   dst.gainTenths=juce::jlimit(-240,120,s->getIntAttribute("db10",0));
   dst.distanceCm=juce::jlimit(0,1500,s->getIntAttribute("cm",200));
   dst.angleDeg=juce::jlimit(-180,180,s->getIntAttribute("angle",ch==0?-35:ch==1?35:ch==2?0:ch==3?180:ch==4?-145:ch==5?145:ch==6?-90:90));
   for(int b=0;b<bands;++b){
    dst.eqTenths[b]=juce::jlimit(-120,120,s->getIntAttribute("g"+juce::String(b),0));
    dst.eqFreq[b]=juce::jlimit(40,14000,s->getIntAttribute("f"+juce::String(b),b==0?125:b==1?1000:6000));
    dst.eqQ100[b]=juce::jlimit(30,500,s->getIntAttribute("q"+juce::String(b),100));
   }
  }
 }
}
inline void save(){
 auto& c=controls();
 auto file=stateFile(); file.getParentDirectory().createDirectory();
 juce::XmlElement xml("room-studio-v1");
 xml.setAttribute("enabled",c.enabled.load());
 xml.setAttribute("width",c.widthPercent.load());
 xml.setAttribute("wrap",c.wrapPercent.load());
 xml.setAttribute("wrapMs",c.wrapDelayMs.load());
 for(int ch=0;ch<speakers;++ch){
  auto* s=xml.createNewChildElement("speaker"+juce::String(ch));
  auto& src=c.channel[ch];
  s->setAttribute("on",src.enabled.load());
  s->setAttribute("db10",src.gainTenths.load());
  s->setAttribute("cm",src.distanceCm.load());
  s->setAttribute("angle",src.angleDeg.load());
  for(int b=0;b<bands;++b){
   s->setAttribute("g"+juce::String(b),src.eqTenths[b].load());
   s->setAttribute("f"+juce::String(b),src.eqFreq[b].load());
   s->setAttribute("q"+juce::String(b),src.eqQ100[b].load());
  }
 }
 xml.writeTo(file);
}
class RoomMap final : public juce::Component {
 int dragging_=-1;
 float scale=37.f;
 juce::Point<float> chairShift;
 std::array<juce::Point<float>,8> anchors;
 juce::Point<float> chair()const{return juce::Point<float>(getWidth()*.5f,getHeight()*.47f)+chairShift;}
 static juce::Point<float> spot(int ch,juce::Point<float> centre,float pxPerMetre){
  auto& c=controls().channel[ch];
  int degrees=c.angleDeg.load();
  const float rad=juce::degreesToRadians(float(degrees));
  const float radius=float(c.distanceCm.load())*pxPerMetre/100.f;
  return {centre.x+radius*std::sin(rad),centre.y-radius*std::cos(rad)};
 }
 void updateDrag(juce::Point<float> at){
  if(dragging_==-1)return;
  auto set=[&](int ch,juce::Point<float> offset){
   auto& c=controls().channel[ch];c.distanceCm=juce::jlimit(0,1500,int(std::lround(offset.getDistanceFromOrigin()*100.f/scale)));
   c.angleDeg=int(std::lround(180.f*std::atan2(offset.x,-offset.y)/3.14159265f));};
  if(dragging_==-2){at.x=juce::jlimit(25.f,getWidth()-25.f,at.x);at.y=juce::jlimit(30.f,getHeight()-65.f,at.y);
   chairShift=at-juce::Point<float>(getWidth()*.5f,getHeight()*.47f);
   for(int ch=0;ch<8;ch++)set(ch,anchors[ch]-at);
  }else set(dragging_,at-chair());
  repaint();
 }
public:
 RoomMap(){setSize(530,520);int furthest=200;for(auto& ch:controls().channel)furthest=juce::jmax(furthest,ch.distanceCm.load());scale=juce::jmin(37.f,17400.f/furthest);}
 void paint(juce::Graphics& g)override{
  const auto centre=chair();
  g.fillAll(juce::Colour(0xff101e32));
  g.setColour(juce::Colour(0xff304f70));
  for(int metre=1;metre<=5;++metre){
   float radius=metre*scale;
   g.drawEllipse(centre.x-radius,centre.y-radius,radius*2.f,radius*2.f,1.0f);
  }
  g.drawLine(centre.x,38.f,centre.x,float(getHeight()-55),.7f);
  g.drawLine(60.f,centre.y,float(getWidth()-60),centre.y,.7f);
  g.setColour(juce::Colour(0xffeef7ff));
  g.fillEllipse(centre.x-7.f,centre.y-7.f,14.f,14.f);
  g.setFont(12.f);g.drawText("LISTENER",int(centre.x)-38,int(centre.y)+12,76,20,juce::Justification::centred);
  for(int ch=0;ch<speakers;++ch){
   auto p=spot(ch,centre,scale);
   g.setColour(juce::Colour(0xff6387a6));
   g.drawLine(centre.x,centre.y,p.x,p.y,1.f);
   g.setColour(controls().channel[ch].enabled.load()?juce::Colour(0xff38aafa):juce::Colour(0xff707070));
   g.fillRoundedRectangle(p.x-12,p.y-12,24,24,5.f);
   g.setColour(juce::Colour(0xff101010));g.setFont(13.f);
   g.drawText(juce::String(ch+1),int(p.x)-12,int(p.y)-12,24,24,juce::Justification::centred);
  }
  g.setColour(juce::Colour(0xffd1e7fc));
  g.setFont(14.f);
  g.drawText("Drag the chair or a numbered speaker to align arrival times.",10,getHeight()-54,getWidth()-20,20,juce::Justification::centred);
  g.setFont(12.f);
  g.drawText("Orientation is visual only; Windows 7.1 channel routing stays fixed.",10,getHeight()-30,getWidth()-20,18,juce::Justification::centred);
 }
 void mouseDown(const juce::MouseEvent& event)override{
  auto centre=chair();
  int nearest=-1;float distance=24.f;
  for(int ch=0;ch<speakers;++ch){
   float gap=spot(ch,centre,scale).getDistanceFrom(event.position);
   if(gap<distance){nearest=ch;distance=gap;}
  }
  if(centre.getDistanceFrom(event.position)<10.f){dragging_=-2;for(int ch=0;ch<8;ch++)anchors[ch]=spot(ch,centre,scale);}
  else dragging_=nearest;
 }
 void mouseDrag(const juce::MouseEvent& event)override{updateDrag(event.position);}
 void mouseUp(const juce::MouseEvent& event)override{updateDrag(event.position);dragging_=-1;save();}
};
inline void showMap(){
 juce::DialogWindow::LaunchOptions o;
 o.dialogTitle="FxSound Room / Speaker distance map";
 o.dialogBackgroundColour=juce::Colour(0xff101e32);
 o.content.setOwned(new RoomMap());o.useNativeTitleBar=true;o.resizable=false;o.launchAsync();
}

class Panel final : public juce::Component, private juce::Timer {
 juce::ToggleButton enabled_{"Enable Studio processing"};
 juce::ToggleButton solo_{"Solo selected channels"};
 juce::Label status_,help_,heading_,gainLabel_,distanceLabel_,widthLabel_,wrapLabel_,wrapDelayLabel_,eqHead_;
 juce::TextButton pick_[speakers];
 juce::ToggleButton live_[speakers];
 juce::TextButton selectAll_{"All speakers"}, selectFront_{"Front L/R"}, selectSurround_{"Surrounds"},roomMap_{"Speaker room map"};
 juce::Slider gain_,distance_,width_,wrap_,wrapDelay_;
 juce::Slider frequency_[bands],eqGain_[bands],eqQ_[bands];
 juce::Label bandLabels_[bands];
 juce::ComboBox test_;
 bool updating_=false;
 int currentMask()const{return controls().selectedMask.load();}
 void applySelected(const std::function<void(ChannelSettings&)>& fn){
  for(int ch=0;ch<speakers;++ch)if((currentMask()>>ch)&1)fn(controls().channel[ch]);
 }
 void choose(int mask){
  controls().selectedMask=mask&255;
  if(!controls().selectedMask.load())controls().selectedMask=255;
  if(solo_.getToggleState())controls().soloMask=controls().selectedMask.load();
  updateView();
 }
 static void prepare(juce::Slider& s,double low,double hi,double step){
  s.setRange(low,hi,step);
  s.setSliderStyle(juce::Slider::LinearHorizontal);
  s.setTextBoxStyle(juce::Slider::TextBoxRight,false,75,25);
 }
 void updateView(){
  updating_=true;
  int mask=currentMask();int first=0;
  for(int ch=0;ch<speakers;++ch){
   const bool selected=(mask>>ch)&1;
   pick_[ch].setToggleState(selected,juce::dontSendNotification);
   live_[ch].setToggleState(controls().channel[ch].enabled.load()!=0,juce::dontSendNotification);
   if(selected){first=ch;break;}
  }
  for(int ch=0;ch<speakers;++ch){
   pick_[ch].setToggleState((mask>>ch)&1,juce::dontSendNotification);
   live_[ch].setToggleState(controls().channel[ch].enabled.load()!=0,juce::dontSendNotification);
  }
  auto& c=controls().channel[first];
  gain_.setValue(double(c.gainTenths.load())/10.,juce::dontSendNotification);
  distance_.setValue(double(c.distanceCm.load())/100.,juce::dontSendNotification);
  for(int b=0;b<bands;++b){
   frequency_[b].setValue(c.eqFreq[b].load(),juce::dontSendNotification);
   eqGain_[b].setValue(double(c.eqTenths[b].load())/10.,juce::dontSendNotification);
   eqQ_[b].setValue(double(c.eqQ100[b].load())/100.,juce::dontSendNotification);
  }
  help_.setText("Shared sliders apply to every selected speaker. Values shown are from the first selected.",juce::dontSendNotification);
  updating_=false;
 }
 void timerCallback()override{
  const int detected=controls().detectedChannels.load();
  const bool supported=controls().supported.load()!=0;
  juce::String status;
  if(detected==0)status="Audio not detected yet: start playback";
  else status=juce::String(detected)+" channels / "+juce::String(controls().detectedRate.load())+" Hz";
  if(detected && !supported)status+=" / configure output as Windows 7.1 Surround";
  else if(supported)status+=" / 7.1 endpoint available";
  if(!room::controls().power.load())status+=" / FxSound power is off";
  if(controls().testSpeaker.load()>=0)status+=" / test tone active (while audio streams)";
  status_.setText(status,juce::dontSendNotification);
 }
public:
 Panel(){
  auto& c=controls();
  addAndMakeVisible(enabled_);
  enabled_.setToggleState(c.enabled.load()!=0,juce::dontSendNotification);
  enabled_.onClick=[] {controls().enabled=controls().enabled.load()?0:1;save();};
  for(auto* p:{&status_,&help_,&heading_,&gainLabel_,&distanceLabel_,&widthLabel_,&wrapLabel_,&wrapDelayLabel_,&eqHead_})addAndMakeVisible(*p);
  heading_.setText("Select speakers to edit together",juce::dontSendNotification);
  gainLabel_.setText("Gain (dB)",juce::dontSendNotification);
  distanceLabel_.setText("Distance from listener (m)",juce::dontSendNotification);
  widthLabel_.setText("Front stereo width (%)",juce::dontSendNotification);
  wrapLabel_.setText("Surround reflections (%)",juce::dontSendNotification);
  wrapDelayLabel_.setText("Reflection spacing (ms)",juce::dontSendNotification);
  eqHead_.setText("3-band parametric EQ per selected speaker",juce::dontSendNotification);
  for(int ch=0;ch<speakers;++ch){
   auto& btn=pick_[ch];
   addAndMakeVisible(btn);btn.setButtonText(speakerName[ch]);btn.setClickingTogglesState(true);
   btn.onClick=[this,ch]{
    int mask=currentMask()^(1<<ch);
    choose(mask?mask:(1<<ch));
   };
   auto& on=live_[ch];
   addAndMakeVisible(on);on.setButtonText("On");
   on.onClick=[this,ch]{controls().channel[ch].enabled=live_[ch].getToggleState();save();};
  }
  for(auto* b:{&selectAll_,&selectFront_,&selectSurround_})addAndMakeVisible(*b);
  selectAll_.onClick=[this]{choose(255);};
  selectFront_.onClick=[this]{choose(3);};
  selectSurround_.onClick=[this]{choose(0xf0);};
  addAndMakeVisible(roomMap_);roomMap_.onClick=[]{showMap();};
  addAndMakeVisible(solo_);
  solo_.onClick=[this]{controls().soloMask=solo_.getToggleState()?currentMask():0;};
  prepare(gain_,-24,12,.1);prepare(distance_,0,15,.01);
  addAndMakeVisible(gain_);addAndMakeVisible(distance_);
  gain_.onValueChange=[this]{if(!updating_)applySelected([this](ChannelSettings& s){s.gainTenths=int(std::lround(gain_.getValue()*10));});};
  gain_.onDragEnd=[]{save();};
  distance_.onValueChange=[this]{if(!updating_)applySelected([this](ChannelSettings& s){s.distanceCm=int(std::lround(distance_.getValue()*100));});};
  distance_.onDragEnd=[]{save();};
  prepare(width_,0,200,1);prepare(wrap_,0,80,1);prepare(wrapDelay_,5,70,1);
  for(auto* slider:{&width_,&wrap_,&wrapDelay_})addAndMakeVisible(*slider);
  width_.setValue(c.widthPercent.load(),juce::dontSendNotification);
  wrap_.setValue(c.wrapPercent.load(),juce::dontSendNotification);
  wrapDelay_.setValue(c.wrapDelayMs.load(),juce::dontSendNotification);
  width_.onValueChange=[this]{controls().widthPercent=int(width_.getValue());};
  width_.onDragEnd=[]{save();};
  wrap_.onValueChange=[this]{controls().wrapPercent=int(wrap_.getValue());};
  wrap_.onDragEnd=[]{save();};
  wrapDelay_.onValueChange=[this]{controls().wrapDelayMs=int(wrapDelay_.getValue());};
  wrapDelay_.onDragEnd=[]{save();};
  for(int b=0;b<bands;++b){
   addAndMakeVisible(bandLabels_[b]);
   bandLabels_[b].setText("Band "+juce::String(b+1),juce::dontSendNotification);
   prepare(frequency_[b],40,14000,1);
   frequency_[b].setSkewFactorFromMidPoint(1000);
   prepare(eqGain_[b],-12,12,.1);
   prepare(eqQ_[b],.3,5,.05);
   addAndMakeVisible(frequency_[b]);addAndMakeVisible(eqGain_[b]);addAndMakeVisible(eqQ_[b]);
   frequency_[b].onValueChange=[this,b]{if(!updating_)applySelected([this,b](ChannelSettings& s){s.eqFreq[b]=int(frequency_[b].getValue());});};
   frequency_[b].onDragEnd=[]{save();};
   eqGain_[b].onValueChange=[this,b]{if(!updating_)applySelected([this,b](ChannelSettings& s){s.eqTenths[b]=int(std::lround(eqGain_[b].getValue()*10));});};
   eqGain_[b].onDragEnd=[]{save();};
   eqQ_[b].onValueChange=[this,b]{if(!updating_)applySelected([this,b](ChannelSettings& s){s.eqQ100[b]=int(std::lround(eqQ_[b].getValue()*100));});};
   eqQ_[b].onDragEnd=[]{save();};
  }
  addAndMakeVisible(test_);
  test_.addItem("No speaker test",1);
  for(int ch=0;ch<speakers;++ch)test_.addItem(speakerName[ch],ch+2);
  test_.setSelectedId(1,juce::dontSendNotification);
  test_.onChange=[this]{controls().testSpeaker=test_.getSelectedId()-2;};
  updateView();
  setSize(970,625);
  timerCallback();startTimerHz(3);
 }
 void visibilityChanged()override{if(isShowing()){enabled_.setToggleState(controls().enabled.load()!=0,juce::dontSendNotification);updateView();}}
 ~Panel()override{controls().testSpeaker=-1;controls().soloMask=0;save();}
 void resized()override{
  const int left=18,right=getWidth()-18;
  enabled_.setBounds(left,12,240,30);status_.setBounds(270,12,right-275,30);
  heading_.setBounds(left,51,330,23);
  selectAll_.setBounds(right-374,48,110,25);
  selectFront_.setBounds(right-255,48,110,25);
  selectSurround_.setBounds(right-136,48,136,25);
  const int gap=4,cw=(right-left-7*gap)/8;
  for(int ch=0;ch<speakers;++ch){
   const int x=left+ch*(cw+gap);
   pick_[ch].setBounds(x,80,cw,30);
   live_[ch].setBounds(x+cw/2-28,112,65,27);
  }
  help_.setBounds(left,146,right-left,24);
  const int colLeft=left,colRight=492;
  gainLabel_.setBounds(colLeft,190,190,24);gain_.setBounds(colLeft+190,187,270,28);
  distanceLabel_.setBounds(colLeft,237,190,24);distance_.setBounds(colLeft+190,234,270,28);
  widthLabel_.setBounds(colLeft,294,190,24);width_.setBounds(colLeft+190,291,270,28);
  wrapLabel_.setBounds(colLeft,336,190,24);wrap_.setBounds(colLeft+190,333,270,28);
  wrapDelayLabel_.setBounds(colLeft,378,190,24);wrapDelay_.setBounds(colLeft+190,375,270,28);
  solo_.setBounds(colLeft,448,230,28);test_.setBounds(colLeft+238,448,217,28);
  roomMap_.setBounds(colLeft,500,455,36);
  eqHead_.setBounds(colRight,186,470,28);
  for(int b=0;b<bands;++b){
   int y=226+b*114;
   bandLabels_[b].setBounds(colRight,y,150,22);
   frequency_[b].setBounds(colRight,y+24,225,31);
   eqGain_[b].setBounds(colRight+230,y+24,226,31);
   eqQ_[b].setBounds(colRight,y+62,225,31);
  }
 }
};
inline void show(){
 juce::DialogWindow::LaunchOptions o;
 o.dialogTitle="FxSound Room / Studio";
 o.dialogBackgroundColour=juce::Colour(0xff14243b);
 o.content.setOwned(new Panel());
 o.useNativeTitleBar=true;
 o.resizable=false;
 o.launchAsync();
}
}
