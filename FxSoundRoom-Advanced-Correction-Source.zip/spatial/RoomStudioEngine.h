// FxSound Room Studio add-on; AGPL-3.0-or-later.
// Original RoomEngine.h is unchanged. All Studio defaults are transparent.
#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include "RoomEngine.h"
#include "fluideq/biquad.h"

namespace roomstudio {
constexpr int speakers = 8;
constexpr int bands = 3;
constexpr int speakerMask71 = 0x63f; // FL FR FC LFE BL BR SL SR (WAVEFORMATEXTENSIBLE)
constexpr const char* speakerName[speakers] = {
  "Front left", "Front right", "Centre", "Subwoofer", "Rear left", "Rear right", "Side left", "Side right"
};
struct ChannelSettings {
 std::atomic<int> enabled{1};
 std::atomic<int> gainTenths{0};         // dB * 10 [-240,+120]
 std::atomic<int> distanceCm{200};       // centimetres [0,1500]
 std::atomic<int> offsetUs{0};
 std::atomic<int> angleDeg{0};          // physical map orientation, for distance-only alignment
 std::atomic<int> eqTenths[bands];       // peaking bell gain, dB * 10
 std::atomic<int> eqFreq[bands];         // Hz
 std::atomic<int> eqQ100[bands];         // Q * 100
 ChannelSettings(){
  const int defaultFreq[bands]={125,1000,6000};
  for(int b=0;b<bands;++b){eqTenths[b]=0; eqFreq[b]=defaultFreq[b]; eqQ100[b]=100;}
 }
};
struct Controls {
 std::atomic<int> enabled{0};
 std::atomic<int> selectedMask{255};
 std::atomic<int> widthPercent{100};     // front width 0..200
 std::atomic<int> wrapPercent{0};       // side/rear reflections, 0..80
 std::atomic<int> wrapDelayMs{25};
 std::atomic<int> testSpeaker{-1};      // -1 normal music, 0..7 test tone
 std::atomic<int> soloMask{0};         // 0 means no solo; otherwise audible subset
 std::atomic<int> detectedChannels{0};
 std::atomic<int> detectedRate{0};
 std::atomic<int> supported{0};
 ChannelSettings channel[speakers];
 Controls(){
  const int angles[speakers]={-35,35,0,180,-145,145,-90,90};
  for(int ch=0;ch<speakers;++ch)channel[ch].angleDeg=angles[ch];
 }
};
inline Controls& controls(){static Controls s; return s;}

struct Biquad {
 float b0=1,b1=0,b2=0,a1=0,a2=0, z1=0,z2=0;
 void coefficients(int hz, int q100, int gain10, int rate){
  if(gain10==0 || hz>=rate*0.49f){b0=1; b1=b2=a1=a2=0;return;}
  const auto k=feq_biquad_coefficients(FEQ_FILTER_PK,hz,gain10*.1,q100*.01,rate);
  b0=float(k.b0);b1=float(k.b1);b2=float(k.b2);a1=float(k.a1);a2=float(k.a2);
 }
 float run(float x){
  const float y=b0*x+z1;
  z1=b1*x-a1*y+z2;
  z2=b2*x-a2*y;
  // Avoid long-running denormal slowdowns on silent audio.
  if(std::abs(z1)<1e-20f)z1=0;
  if(std::abs(z2)<1e-20f)z2=0;
  return y;
 }
 void clear(){z1=z2=0;}
};

// This is a second processing stage, not a replacement for FxSound or RoomEngine.
// It performs no allocations, locks, file I/O, or UI operations in the audio callback.
class Engine {
 static constexpr unsigned ringSize=32768, ringMask=ringSize-1;
 std::array<std::array<float,ringSize>,speakers> histories{};
 std::array<float,ringSize> frontHistory{};
 std::array<std::array<Biquad,bands>,speakers> equalizers{};
 float smoothedDelays[speakers]{};
 float phase=0.f;
 uint64_t processed=0;
 int lastRate=0;
 bool wasEnabled=false;
 unsigned position=0;
 static float clamp(float v){return (std::max)(-1.f,(std::min)(1.f,v));}
 static float read(const std::array<float,ringSize>& ring, unsigned pos,float offset){
  const float lag=(std::max)(0.f,(std::min)(float(ringSize-3),offset));
  const unsigned i=unsigned(lag);
  const float frac=lag-i;
  const float a=ring[(pos-i)&ringMask],b=ring[(pos-i-1)&ringMask];
  return a+(b-a)*frac;
 }
public:
 void reset(){
  for(auto& h:histories)h.fill(0.f);
  frontHistory.fill(0.f);
  for(auto& ch:equalizers)for(auto& eq:ch)eq.clear();
  for(float& delay:smoothedDelays)delay=0.f;
  phase=0;processed=0;position=0;lastRate=0;wasEnabled=false;
 }
 void process(float* samples,int frames,int channels,int sampleRate,unsigned mask,bool comparison=false,bool protect=false){
  Controls& c=controls();
  const bool valid=channels==8 && mask==speakerMask71 && sampleRate>=22050 && sampleRate<=192000;
  c.detectedChannels.store(channels,std::memory_order_relaxed);
  c.detectedRate.store(sampleRate,std::memory_order_relaxed);
  c.supported.store(valid?1:0,std::memory_order_relaxed);
  if(!valid || !c.enabled.load(std::memory_order_relaxed) || !room::controls().power.load(std::memory_order_relaxed)){
   // Never touch the original FxSound buffers when the add-on is disabled.
   if(wasEnabled)reset();
   return;
  }
  if(frames<=0 || samples==nullptr)return;
  if(lastRate!=sampleRate){reset();lastRate=sampleRate;wasEnabled=true;}
  wasEnabled=true;
  int gain10[speakers],dist[speakers],live[speakers];
  float gain[speakers],targetDelay[speakers];
  int maxCm=0;
  for(int ch=0;ch<speakers;++ch){
   auto& s=c.channel[ch];
   live[ch]=s.enabled.load(std::memory_order_relaxed);
   gain10[ch]=(std::max)(-240,(std::min)(120,s.gainTenths.load(std::memory_order_relaxed)));
   gain[ch]=float(std::pow(10.0,double(gain10[ch])/200.0));
   dist[ch]=(std::max)(0,(std::min)(1500,s.distanceCm.load(std::memory_order_relaxed)));
   if(dist[ch]>maxCm)maxCm=dist[ch];
   for(int b=0;b<bands;++b){
    equalizers[ch][b].coefficients(
      s.eqFreq[b].load(std::memory_order_relaxed),
      s.eqQ100[b].load(std::memory_order_relaxed),
      s.eqTenths[b].load(std::memory_order_relaxed),sampleRate);
   }
  }
  for(int ch=0;ch<speakers;++ch){
   targetDelay[ch]=float(maxCm-dist[ch])*float(sampleRate)/34300.f;
   targetDelay[ch]+=c.channel[ch].offsetUs.load()*(sampleRate/1000000.f);
  }
  float minimum=*std::min_element(targetDelay,targetDelay+speakers);
  for(int ch=0;ch<speakers;ch++){targetDelay[ch]=(std::min)(float(ringSize-3),targetDelay[ch]-minimum);if(!processed)smoothedDelays[ch]=targetDelay[ch];}
  const float width=float((std::max)(0,(std::min)(200,c.widthPercent.load())))/100.f;
  const float wrap=float((std::max)(0,(std::min)(80,c.wrapPercent.load())))/100.f;
  const float wrapDelay=float((std::max)(5,(std::min)(70,c.wrapDelayMs.load())))*float(sampleRate)/1000.f;
  const int test=c.testSpeaker.load(std::memory_order_relaxed);
  const int solo=c.soloMask.load(std::memory_order_relaxed);
  constexpr float twoPi=6.28318530717958647692f;
  const float phaseStep=twoPi*(test==3?65.f:440.f)/float(sampleRate);
  for(int f=0;f<frames;++f,samples+=channels){
   // Width and wrap use audio before channel correction. Centre remains unchanged.
   const float mid=.5f*(samples[0]+samples[1]);
   const float side=.5f*(samples[0]-samples[1]);
   const float origL=samples[0],origR=samples[1];
   float in[speakers];for(int ch=0;ch<speakers;++ch)in[ch]=samples[ch];
   if(!comparison){in[0]=mid+side*width;in[1]=mid-side*width;}
   if(wrap>0.f && !comparison){
    // Reflection-only surround expansion. No source separation claims.
    const float a=read(frontHistory,position,wrapDelay), b=read(frontHistory,position,wrapDelay*1.57f);
    in[6]+=.23f*wrap*a;
    in[7]-=.23f*wrap*a;
    in[4]+=.20f*wrap*b;
    in[5]-=.20f*wrap*b;
   }
   frontHistory[position&ringMask]=.5f*(origL+origR);
   for(int ch=0;ch<speakers;++ch){
    float x=in[ch];
    for(int b=0;b<bands;++b)x=equalizers[ch][b].run(x);
    x*=gain[ch];
    // Write before reading. Interpolated fractional channel delays for accurate alignment.
    histories[ch][position&ringMask]=x;
    const float maxStep=0.18f; // prevent abrupt travel-time jumps while dragging sliders
    const float delta=(std::max)(-maxStep,(std::min)(maxStep,targetDelay[ch]-smoothedDelays[ch]));
    smoothedDelays[ch]+=delta;
    samples[ch]=(live[ch] && (!solo || ((solo>>ch)&1)))
      ?read(histories[ch],position,smoothedDelays[ch]):0.f;
    if(!protect)samples[ch]=clamp(samples[ch]);
   }
   if(test>=0 && test<speakers){
    // Quiet diagnostic sine, -24 dBFS peak; replaces music while active.
    const float signal=.0630957f*std::sin(phase);
    for(int ch=0;ch<speakers;++ch)samples[ch]=(ch==test && live[ch])?signal:0.f;
   }
   phase+=phaseStep;
   if(phase>=twoPi)phase-=twoPi;
   ++position;
  }
  processed+=uint64_t(frames);
 }
};
} // namespace roomstudio
