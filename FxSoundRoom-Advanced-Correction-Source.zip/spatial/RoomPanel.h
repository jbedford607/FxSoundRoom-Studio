// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <JuceHeader.h>
#include "RoomEngine.h"
namespace room {
inline File stateFile(){return File::getSpecialLocation(File::userApplicationDataDirectory).getChildFile("FxSound Room").getChildFile("spatial.xml");}
inline void restore(){if(auto xml=XmlDocument::parse(stateFile()))for(int i=0;i<count;++i)
 controls().value[i]=jlimit(spec[i].lo,spec[i].hi,xml->getIntAttribute("p"+String(i>=note?i+2:i),spec[i].initial));}
inline void save(){auto file=stateFile();file.getParentDirectory().createDirectory();XmlElement xml("room");
 for(int i=0;i<count;++i) xml.setAttribute("p"+String(i>=note?i+2:i),controls().value[i].load());xml.writeTo(file);}
class Panel final:public Component, private Timer {
 ToggleButton toggle{"Enable 7.1 upmix"}; Label status;
 Label names[count]; Slider sliders[count]; ComboBox choices[count];
 static String noteName(int m){const char* names[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};return String(names[m%12])+String(m/12-1);}
 static bool choice(int i){return i==note||i==noteDest||i==bandDest;}
 void timerCallback()override{auto& c=controls();
  String s=c.channels.load()==0?"Play audio to detect the output layout":String(c.channels.load())+" channels   /   "+String(c.rate.load())+" Hz";
  if(c.channels.load() && !c.valid.load())s+="   /   Select Windows 7.1 Surround";
  else if(!c.power.load())s+="   /   FxSound power is off";
  status.setText(s,dontSendNotification);}
public:
 Panel(){addAndMakeVisible(toggle);addAndMakeVisible(status);
  toggle.setToggleState(controls().value[enabled].load()!=0,dontSendNotification);
  toggle.onClick=[this]{controls().value[enabled]=toggle.getToggleState();save();};
  for(int i=1;i<count;++i){
   addAndMakeVisible(names[i]);names[i].setText(spec[i].label,dontSendNotification);
   if(choice(i)){auto& box=choices[i];addAndMakeVisible(box);
    if(i==note){for(int m=spec[i].lo;m<=spec[i].hi;++m)box.addItem(noteName(m),m+1);}
    else {int id=1;for(auto name:{"Front left","Front right","Centre","Rear left","Rear right","Side left","Side right"})box.addItem(name,id++);}
    box.setSelectedId(controls().value[i]+1,dontSendNotification);
    box.onChange=[this,i]{controls().value[i]=choices[i].getSelectedId()-1;save();};
   } else {auto& s=sliders[i];addAndMakeVisible(s);s.setRange(spec[i].lo,spec[i].hi,1);
    s.setTextBoxStyle(Slider::TextBoxRight,false,62,22);s.setValue(controls().value[i],dontSendNotification);
    s.onValueChange=[this,i]{controls().value[i]=int(sliders[i].getValue());};
    s.onDragEnd=[]{save();};}
  }
  setSize(550,490);timerCallback();startTimerHz(3);
 }
 void visibilityChanged()override{if(!isShowing())return;auto& v=controls().value;toggle.setToggleState(v[enabled]!=0,dontSendNotification);for(int i=1;i<count;i++){if(choice(i))choices[i].setSelectedId(v[i]+1,dontSendNotification);else sliders[i].setValue(v[i],dontSendNotification);}}
 ~Panel()override{save();}
 void resized()override{auto area=getLocalBounds().reduced(16,8);toggle.setBounds(area.removeFromTop(30));status.setBounds(area.removeFromTop(28));
  for(int i=1;i<count;++i){auto row=area.removeFromTop(29);names[i].setBounds(row.removeFromLeft(202));
   if(choice(i))choices[i].setBounds(row.reduced(1,2));else sliders[i].setBounds(row);}
 }
};
inline void show(){juce::DialogWindow::LaunchOptions o;o.dialogTitle="Spatial room / 7.1";o.dialogBackgroundColour=Colour(0xff14243b);
 o.content.setOwned(new Panel);o.useNativeTitleBar=true;o.resizable=false;o.launchAsync();}
}
