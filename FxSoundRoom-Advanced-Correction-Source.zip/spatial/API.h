#pragma once
namespace studio {
bool input(float*,int frames,int channels,int rate);
void render(float*,int frames,int channels,int rate,unsigned mask);
void open();
void load();
void shut();
}
